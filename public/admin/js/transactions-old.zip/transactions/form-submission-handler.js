/**
 * Form Submission Handler
 * Handles form submission logic for sales invoices and journal entries
 */
class FormSubmissionHandler {
    constructor() {
        // Will be initialized in initialize() method
    }

    initialize() {
        console.log('✅ FormSubmissionHandler initialized');
    }

    /**
     * Submit sales invoice form with specified action
     * @param {string} action - save, save_and_email, save_and_add_new, save_as_draft, preview
     */
    submitSalesInvoiceForm(action) {
        const currentPaymentType = window.formManager.getCurrentPaymentType();

        // Validate journal entries if journal type
        if (currentPaymentType === 'journal' && !window.journalHandler.validateJournalTable()) {
            return false;
        }

        let salesForm = document.getElementById('salesInvoiceTransactionForm') ||
            document.querySelector('#salesInvoiceForm form') ||
            document.querySelector('.sales-invoice-form form') ||
            document.querySelector('form[action*="transactions.store"]');

        if (!salesForm) {
            alert('Error: Could not find the invoice form. Please refresh the page and try again.');
            return false;
        }

        try {
            // Ensure payment type is set correctly
            let paymentTypeField = document.getElementById('salesInvoicePaymentType');
            if (!paymentTypeField) {
                paymentTypeField = document.createElement('input');
                paymentTypeField.type = 'hidden';
                paymentTypeField.name = 'current_payment_type';
                paymentTypeField.id = 'salesInvoicePaymentType';
                salesForm.appendChild(paymentTypeField);
            }
            paymentTypeField.value = currentPaymentType;

            // Set action field
            const existingActionFields = salesForm.querySelectorAll('input[name="action"]');
            existingActionFields.forEach(field => field.remove());

            const actionField = document.createElement('input');
            actionField.type = 'hidden';
            actionField.name = 'action';
            actionField.value = action;
            salesForm.appendChild(actionField);

            // For journal entries, ensure amount field is updated and add summary data
            if (currentPaymentType === 'journal') {
                window.journalHandler.updateJournalAmountField();

                // Add comprehensive journal summary data for server-side validation
                const existingSummaryFields = salesForm.querySelectorAll('input[name="journal_summary"]');
                existingSummaryFields.forEach(field => field.remove());

                const totalDebit = parseFloat(document.getElementById('journalTotalDebit')?.textContent || 0);
                const totalCredit = parseFloat(document.getElementById('journalTotalCredit')?.textContent || 0);

                const journalSummary = document.createElement('input');
                journalSummary.type = 'hidden';
                journalSummary.name = 'journal_summary';
                journalSummary.value = JSON.stringify({
                    total_debit: totalDebit,
                    total_credit: totalCredit,
                    difference: totalDebit - totalCredit,
                    entry_count: document.querySelectorAll('#journalRows tr:not([data-template-row])').length,
                    is_balanced: Math.abs(totalDebit - totalCredit) < 0.01
                });
                salesForm.appendChild(journalSummary);

                console.log('Journal data being submitted:');
                console.log('- Summary:', {
                    total_debit: totalDebit,
                    total_credit: totalCredit,
                    difference: totalDebit - totalCredit,
                    is_balanced: Math.abs(totalDebit - totalCredit) < 0.01
                });
                console.log('- Entries:', window.journalHandler.collectJournalData());
            } else {
                // For other payment types, handle invoice summary
                window.invoiceHandler.updateInvoiceSummary();
            }

            // Update transaction codes
            if (window.codeManager) window.codeManager.syncTransactionCode();

            // Debug: Log all form data being submitted
            const formData = new FormData(salesForm);
            console.log('All form data being submitted:');
            for (let [key, value] of formData.entries()) {
                if (key.includes('journal_items') || key === 'journal_summary' || key === 'Amount' || key === 'current_payment_type') {
                    console.log(key + ': ' + value);
                }
            }

            // Ensure Amount field exists
            let hasAmount = false;
            for (let [key, value] of formData.entries()) {
                if (key === 'Amount') {
                    hasAmount = true;
                    break;
                }
            }

            if (!hasAmount) {
                alert('Error: Amount field is missing. Please refresh the page and try again.');
                return false;
            }

            // Show success message before submission
            if (currentPaymentType === 'journal') {
                console.log('✅ Journal entries validated and ready for submission!');
            }

            if (action === 'preview') {
                const originalAction = salesForm.getAttribute('action');
                salesForm.setAttribute('action', '/invoicetemplates/preview');
                salesForm.submit();

                salesForm.setAttribute('action', originalAction);
                return;
            }
            
            // Submit the form
            salesForm.submit();

        } catch (error) {
            console.error('Error submitting form:', error);
            alert('Error submitting form: ' + error.message);
        }
    }
}

// Export to window for global access
if (typeof window !== 'undefined') {
    window.FormSubmissionHandler = FormSubmissionHandler;
}